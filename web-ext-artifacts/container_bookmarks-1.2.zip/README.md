# ContainerBookmarks
Firefox extension that adds functionality to open bookmarks in multi-account containers.

https://addons.mozilla.org/en-US/firefox/addon/container_bookmarks/
